/*
 * Copyright (c) 2025 Nikhil Marathe <nikhil@selvejj.com>
 */

package com.selvejj

import com.intellij.openapi.vcs.VcsKey
import com.intellij.openapi.vcs.VcsRootChecker
import com.intellij.openapi.vfs.VirtualFile
import java.nio.file.Files

private const val DOT_JJ = ".jj"

class SelvejjVcsRootChecker : VcsRootChecker() {

    override fun isRoot(file: VirtualFile): Boolean {
        return file.findChild(DOT_JJ)?.isDirectory == true
    }

    override fun validateRoot(file: VirtualFile): Boolean {
        return Files.isDirectory(file.toNioPath().resolve(DOT_JJ))
    }

    override fun getSupportedVcs(): VcsKey {
        return SelvejjVcs.getKey()
    }

    override fun isVcsDir(dirName: String): Boolean {
        // Check if this directory is a .jj directory
        return dirName == DOT_JJ
    }

}
