/*
 * Copyright (c) 2025 Nikhil Marathe <nikhil@selvejj.com>
 */

package com.selvejj

import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory
import com.intellij.openapi.options.Configurable
import com.intellij.openapi.ui.TextBrowseFolderListener
import com.intellij.openapi.ui.TextFieldWithBrowseButton
import com.intellij.ui.components.JBLabel
import com.intellij.ui.components.JBTextField
import com.intellij.util.ui.FormBuilder
import java.awt.BorderLayout
import javax.swing.JComponent
import javax.swing.JPanel

class SelvejjSettingsConfigurable : Configurable {
    private val jjPathField = TextFieldWithBrowseButton(JBTextField())
    private var panel: JPanel? = null

    init {
        jjPathField.addBrowseFolderListener(
            TextBrowseFolderListener(FileChooserDescriptorFactory.createSingleFileNoJarsDescriptor())
        )
    }

    override fun getDisplayName(): String = SelvejjBundle.message("settings.display.name")

    override fun createComponent(): JComponent {
        jjPathField.text = fieldTextFor(SelvejjSettings.getInstance().jjPath)

        val form = FormBuilder.createFormBuilder()
            .addLabeledComponent(SelvejjBundle.message("settings.jj.path.label"), jjPathField)
            .addComponentToRightColumn(
                JBLabel(SelvejjBundle.message("settings.jj.path.description")),
                1
            )
            .addComponentFillVertically(JPanel(), 0)
            .panel

        return JPanel(BorderLayout()).also {
            it.add(form, BorderLayout.NORTH)
            panel = it
        }
    }

    override fun isModified(): Boolean = effectiveJjPath(jjPathField.text) != SelvejjSettings.getInstance().jjPath

    override fun apply() {
        SelvejjSettings.getInstance().jjPath = effectiveJjPath(jjPathField.text)
    }

    override fun reset() {
        jjPathField.text = fieldTextFor(SelvejjSettings.getInstance().jjPath)
    }

    private fun effectiveJjPath(fieldText: String): String = fieldText.trim().ifEmpty { "jj" }

    private fun fieldTextFor(jjPath: String): String = if (jjPath == "jj") "" else jjPath

    override fun disposeUIResources() {
        panel = null
    }
}
