/*
 * Copyright (c) 2025 Nikhil Marathe <nikhil@selvejj.com>
 */

package com.selvejj

import com.intellij.execution.configurations.GeneralCommandLine
import com.intellij.execution.util.ExecUtil
import com.intellij.openapi.Disposable
import com.intellij.openapi.diagnostic.logger
import com.intellij.openapi.project.Project
import com.intellij.openapi.vcs.FilePath
import com.intellij.openapi.vcs.FileStatus
import com.intellij.openapi.vcs.VcsKey
import com.intellij.openapi.vcs.changes.Change
import com.intellij.openapi.vfs.VirtualFile
import com.intellij.util.Consumer
import com.intellij.vcs.log.*
import com.intellij.util.containers.MultiMap
import com.intellij.vcs.log.impl.SimpleRefGroup
import com.intellij.vcs.log.impl.SimpleRefType
import com.intellij.vcs.log.impl.VcsChangesLazilyParsedDetails
import com.intellij.vcs.log.impl.VcsFileStatusInfo
import com.intellij.vcs.log.VcsLogStandardColors
import com.intellij.vcsUtil.VcsUtil
import kotlinx.datetime.Instant
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.DataInput
import java.io.DataOutput
import java.io.IOException
import kotlin.concurrent.thread

@Serializable
data class SelvejjUser(val name: String, val email: String, val timestamp: Instant)

@Serializable
data class SelvejjCommitDetails(
    val commit_id: String,
    val change_id: String,
    val author: SelvejjUser,
    val committer: SelvejjUser,
    val parents: List<String>,
    val description: String
)

@Serializable
data class SelvejjParsedChange(
    val source: String,
    val target: String,
    val status: String
)

@Serializable
data class SelvejjFullCommitDetails(
    val metadata: SelvejjCommitDetails,
    val changes: List<SelvejjParsedChange>
)

@Serializable
data class SelvejjRefTarget(
    val name: String,
    val target: List<String>,
    val remote: String? = null
)

@Serializable
data class SelvejjRefsAtCommit(
    val commit_id: String,
    val local_bookmarks: List<SelvejjRefTarget> = emptyList(),
    val remote_bookmarks: List<SelvejjRefTarget> = emptyList(),
    val tags: List<SelvejjRefTarget> = emptyList(),
    val current_working_copy: Boolean = false
)

class SelvejjVcsLogProvider(private val project: Project) : VcsLogProvider {

    companion object {
        private val LOG = logger<SelvejjVcsLogProvider>()

        private val HEAD_REF_TYPE = SimpleRefType("HEAD", false, VcsLogStandardColors.Refs.TIP)
        private val LOCAL_BOOKMARK_REF_TYPE =
            SimpleRefType("Bookmark", true, VcsLogStandardColors.Refs.BRANCH)
        private val REMOTE_BOOKMARK_REF_TYPE =
            SimpleRefType("Remote bookmark", true, VcsLogStandardColors.Refs.BRANCH_REF)
        private val TAG_REF_TYPE = SimpleRefType("Tag", false, VcsLogStandardColors.Refs.TAG)
        private val REF_TYPES = arrayOf(
            HEAD_REF_TYPE,
            LOCAL_BOOKMARK_REF_TYPE,
            REMOTE_BOOKMARK_REF_TYPE,
            TAG_REF_TYPE
        )

        private const val FULL_COMMIT_JSON_TEMPLATE = "json(self)"
        private const val REFS_JSON_TEMPLATE = """
            '{' ++
            '"commit_id":' ++ json(commit_id) ++ ', ' ++
            '"local_bookmarks":' ++ json(local_bookmarks) ++ ', ' ++
            '"remote_bookmarks":' ++ json(remote_bookmarks) ++ ', ' ++
            '"tags":' ++ json(tags) ++ ', ' ++
            '"current_working_copy":' ++ json(current_working_copy) ++
            '}'
        """
    }


    override fun readFirstBlock(
        root: VirtualFile,
        requirements: VcsLogProvider.Requirements
    ): VcsLogProvider.DetailedLogData {
        try {
            val factory = project.getService(VcsLogObjectsFactory::class.java)
            val commits = loadCommitDetails(
                root,
                "all()",
                FULL_COMMIT_JSON_TEMPLATE,
                requirements.commitCount
            )
            val refs = loadRefs(root, factory)

            val commitMetadata = commits.map { commit ->
                factory.createCommitMetadata(
                    factory.createHash(commit.commit_id),
                    commit.parents.map { factory.createHash(it) },
                    commit.committer.timestamp.toEpochMilliseconds(),
                    root,
                    commit.description.split("\n").firstOrNull().orEmpty(),
                    commit.author.name,
                    commit.author.email,
                    commit.description,
                    commit.committer.name,
                    commit.committer.email,
                    commit.author.timestamp.toEpochMilliseconds()
                )
            }

            return object : VcsLogProvider.DetailedLogData {
                override fun getCommits(): List<VcsCommitMetadata> = commitMetadata
                override fun getRefs(): Set<VcsRef> = refs
            }
        } catch (e: Exception) {
            LOG.warn("Failed to read first block", e)
            return object : VcsLogProvider.DetailedLogData {
                override fun getCommits(): List<VcsCommitMetadata> = emptyList()
                override fun getRefs(): Set<VcsRef> = emptySet()
            }
        }
    }

    override fun readAllHashes(root: VirtualFile, consumer: Consumer<in TimedVcsCommit>): VcsLogProvider.LogData {
        val factory = project.getService(VcsLogObjectsFactory::class.java)
        val users = mutableSetOf<VcsUser>()

        streamCommits(root, "all()", FULL_COMMIT_JSON_TEMPLATE) { commit ->
            consumer.consume(
                factory.createTimedCommit(
                    factory.createHash(commit.commit_id),
                    commit.parents.map { factory.createHash(it) },
                    commit.committer.timestamp.toEpochMilliseconds()
                )
            )

            if (commit.author.email.isNotEmpty()) {
                users.add(factory.createUser(commit.author.name, commit.author.email))
            }
            if (commit.committer.email.isNotEmpty()) {
                users.add(factory.createUser(commit.committer.name, commit.committer.email))
            }
        }

        val refs = loadRefs(root, factory)
        return object : VcsLogProvider.LogData {
            override fun getRefs(): Set<VcsRef> = refs
            override fun getUsers(): Set<VcsUser> = users
        }
    }

    override fun readMetadata(root: VirtualFile, commits: List<String>, consumer: Consumer<in VcsCommitMetadata>) {
        try {
            val factory = project.getService(VcsLogObjectsFactory::class.java)
            val revsetExpression = commits.joinToString(" | ")

            val commitDetails = loadCommitDetails(root, revsetExpression, FULL_COMMIT_JSON_TEMPLATE)

            commitDetails.forEach { commit ->
                consumer.consume(
                    factory.createCommitMetadata(
                        factory.createHash(commit.commit_id),
                        commit.parents.map { factory.createHash(it) },
                        commit.committer.timestamp.toEpochMilliseconds(),
                        root,
                        commit.description.split("\n").firstOrNull().orEmpty(),
                        commit.author.name,
                        commit.author.email,
                        commit.description,
                        commit.committer.name,
                        commit.committer.email,
                        commit.author.timestamp.toEpochMilliseconds(),
                    )
                )
            }
        } catch (e: Exception) {
            LOG.warn("Failed to read metadata for commits: $commits", e)
        }
    }

    override fun readFullDetails(
        root: VirtualFile,
        commits: List<String>,
        consumer: Consumer<in VcsFullCommitDetails>
    ) {
        try {
            val factory = project.getService(VcsLogObjectsFactory::class.java)
            val revsetExpression = commits.joinToString(" | ")

            val fullTemplate = """
                '{' ++
                '"metadata":' ++ $FULL_COMMIT_JSON_TEMPLATE ++ ', ' ++
                '"changes": [' ++ diff.files().map(|f| 
                    '{"status": "' ++ f.status() ++ '", ' ++
                    '"source": "' ++ f.source().path() ++ '", ' ++
                    '"target": "' ++ f.target().path() ++ '"}'
                ).join(', ') ++ ']' ++
                '}'
            """.trimIndent()

            val fullDetails = loadFullCommitDetails(root, revsetExpression, fullTemplate)
            val changesParser = SelvejjChangesParser()

            fullDetails.forEach { detail ->
                val metadata = detail.metadata
                val changes = detail.changes.map { change ->
                    VcsFileStatusInfo(
                        when (change.status) {
                            "removed" -> Change.Type.DELETED
                            "added" -> Change.Type.NEW
                            "modified" -> Change.Type.MODIFICATION
                            "renamed" -> Change.Type.MOVED
                            else -> Change.Type.MODIFICATION
                        },
                        change.source,
                        change.target.ifEmpty { null }
                    )
                }

                val commitDetails = VcsChangesLazilyParsedDetails(
                    project,
                    factory.createHash(metadata.commit_id),
                    metadata.parents.map { factory.createHash(it) },
                    metadata.committer.timestamp.toEpochMilliseconds(),
                    root,
                    metadata.description.split("\n").firstOrNull().orEmpty(),
                    factory.createUser(metadata.author.name, metadata.author.email),
                    metadata.description,
                    factory.createUser(metadata.committer.name, metadata.committer.email),
                    metadata.author.timestamp.toEpochMilliseconds(),
                    listOf(changes),
                    changesParser
                )

                consumer.consume(commitDetails)
            }
        } catch (e: Exception) {
            LOG.warn("Failed to read full details for commits: $commits", e)
        }
    }

    private fun streamCommits(root: VirtualFile, revset: String, template: String, consumer: (SelvejjCommitDetails) -> Unit) {
        val command = GeneralCommandLine(SelvejjSettings.getInstance().jjPath)
            .withParameters("log", "-R", root.path, "--no-graph", "-r", revset, "-T", "$template ++ \"\\n\"")
        val json = Json { ignoreUnknownKeys = true }

        streamJsonLines(command, { line ->
            try {
                json.decodeFromString<SelvejjCommitDetails>(line)
            } catch (e: Exception) {
                throw RuntimeException("Failed to parse commit line from jj log: $line", e)
            }
        }, consumer)
    }

    private fun <T : Any> streamJsonLines(
        command: GeneralCommandLine,
        parser: (String) -> T?,
        consumer: (T) -> Unit
    ) {
        val process = command.createProcess()
        val stderr = StringBuilder()
        val stderrReader = thread(isDaemon = true, name = "selvejj-jj-log-stderr") {
            process.errorStream.bufferedReader().use { stderr.append(it.readText()) }
        }

        try {
            process.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    if (line.trim().isNotEmpty()) {
                        parser(line.trim())?.let(consumer)
                    }
                }
            }

            val exitCode = process.waitFor()
            if (exitCode != 0) {
                throw RuntimeException("jj log command failed with exit code $exitCode: $stderr")
            }
        } finally {
            if (process.isAlive) {
                process.destroyForcibly()
            }
            stderrReader.join(1000)
        }
    }

    private fun loadCommitDetails(
        root: VirtualFile,
        revset: String,
        template: String,
        limit: Int? = null
    ): List<SelvejjCommitDetails> {
        val parameters = mutableListOf(
            "log", "-R", root.path,
            "--no-graph",
            "-r", revset,
            "-T", "$template ++ \"\\n\""
        )
        if (limit != null) {
            parameters.add("--limit")
            parameters.add(limit.toString())
        }

        val command = GeneralCommandLine(SelvejjSettings.getInstance().jjPath)
            .withParameters(parameters)

        val json = Json { ignoreUnknownKeys = true }
        val commits = mutableListOf<SelvejjCommitDetails>()
        streamJsonLines(command, { line ->
            try {
                json.decodeFromString<SelvejjCommitDetails>(line)
            } catch (e: Exception) {
                LOG.warn("Failed to parse commit details line: $line", e)
                null
            }
        }, commits::add)
        return commits
    }

    private fun loadRefs(root: VirtualFile, factory: VcsLogObjectsFactory): Set<VcsRef> {
        val command = GeneralCommandLine(SelvejjSettings.getInstance().jjPath)
            .withParameters(
                "log",
                "-R", root.path,
                "--no-graph",
                "-r", "bookmarks() | remote_bookmarks() | tags() | @",
                "-T", "$REFS_JSON_TEMPLATE ++ \"\\n\""
            )

        val json = Json { ignoreUnknownKeys = true }
        val refs = mutableSetOf<VcsRef>()
        streamJsonLines(command, { line ->
            try {
                json.decodeFromString<SelvejjRefsAtCommit>(line)
            } catch (e: Exception) {
                throw RuntimeException("Failed to parse refs line: $line", e)
            }
        }) { refsAtCommit ->
            val hash = factory.createHash(refsAtCommit.commit_id)
            if (refsAtCommit.current_working_copy) {
                refs.add(factory.createRef(hash, "HEAD", HEAD_REF_TYPE, root))
            }
            refsAtCommit.local_bookmarks.forEach { bookmark ->
                refs.add(factory.createRef(hash, bookmark.name, LOCAL_BOOKMARK_REF_TYPE, root))
            }
            refsAtCommit.remote_bookmarks.forEach { bookmark ->
                refs.add(
                    factory.createRef(
                        hash,
                        "${bookmark.remote}/${bookmark.name}",
                        REMOTE_BOOKMARK_REF_TYPE,
                        root
                    )
                )
            }
            refsAtCommit.tags.forEach { tag ->
                refs.add(factory.createRef(hash, tag.name, TAG_REF_TYPE, root))
            }
        }
        return refs
    }

    private fun loadFullCommitDetails(
        root: VirtualFile,
        revset: String,
        template: String
    ): List<SelvejjFullCommitDetails> {
        val command = GeneralCommandLine(SelvejjSettings.getInstance().jjPath)
            .withParameters("log", "-R", root.path, "--no-graph", "-r", revset, "-T", "$template ++ \"\\n\"")

        val result = ExecUtil.execAndGetOutput(command, 30000)
        if (!result.checkSuccess(LOG)) {
            throw RuntimeException("jj log command failed: ${result.stderr}")
        }

        val json = Json { ignoreUnknownKeys = true }
        return result.stdout.lines()
            .filter { it.trim().isNotEmpty() }
            .mapNotNull { line ->
                try {
                    json.decodeFromString<SelvejjFullCommitDetails>(line.trim())
                } catch (e: Exception) {
                    LOG.warn("Failed to parse full commit details line: $line", e)
                    null
                }
            }
    }

    override fun subscribeToRootRefreshEvents(roots: Collection<VirtualFile>, refresher: VcsLogRefresher): Disposable {
        val connection = project.messageBus.connect()

        // Subscribe to repository change events
        connection.subscribe(SelvejjRepository.JJ_REPO_CHANGE, object : SelvejjRepositoryChangeListener {
            override fun repositoryChanged(repository: SelvejjRepository) {
                if (roots.contains(repository.root)) {
                    LOG.debug("Repository changed, refreshing log: ${repository.root.path}")
                    refresher.refresh(repository.root)
                }
            }
        })

        return connection
    }

    override fun getCurrentUser(root: VirtualFile): VcsUser? {
        try {
            val factory = project.getService(VcsLogObjectsFactory::class.java)

        val nameCommand = GeneralCommandLine(SelvejjSettings.getInstance().jjPath)
                .withParameters("config", "get", "user.name")
                .withWorkDirectory(root.path)
            val nameResult = ExecUtil.execAndGetOutput(nameCommand, 5000)
            val name = if (nameResult.checkSuccess(LOG)) nameResult.stdout.trim() else ""

        val emailCommand = GeneralCommandLine(SelvejjSettings.getInstance().jjPath)
                .withParameters("config", "get", "user.email")
                .withWorkDirectory(root.path)
            val emailResult = ExecUtil.execAndGetOutput(emailCommand, 5000)
            val email = if (emailResult.checkSuccess(LOG)) emailResult.stdout.trim() else ""

            return if (name.isNotEmpty() || email.isNotEmpty()) {
                factory.createUser(name, email)
            } else null
        } catch (e: Exception) {
            LOG.warn("Failed to get current user", e)
            return null
        }
    }

    override fun getCurrentBranch(root: VirtualFile): String? = null

    override fun getContainingBranches(root: VirtualFile, hash: Hash): Collection<String> = emptyList()

    override fun <T : Any> getPropertyValue(property: VcsLogProperties.VcsLogProperty<T>): T? {
        @Suppress("UNCHECKED_CAST")
        return when (property) {
            VcsLogProperties.LIGHTWEIGHT_BRANCHES,
            VcsLogProperties.SUPPORTS_LOG_DIRECTORY_HISTORY,
            VcsLogProperties.HAS_COMMITTER -> true as T

            else -> null
        }
    }

    override fun getReferenceManager(): VcsLogRefManager {
        return object : VcsLogRefManager {
            override fun getLabelsOrderComparator(): Comparator<VcsRef> = Comparator { _, _ -> 0 }
            override fun getBranchLayoutComparator(): Comparator<VcsRef> = Comparator { _, _ -> 0 }
            override fun groupForBranchFilter(refs: Collection<VcsRef>): List<RefGroup> {
                val branchRefs = refs.filter { it.type.isBranch }
                val localRefs = branchRefs.filter { it.type == LOCAL_BOOKMARK_REF_TYPE }
                val remoteGroups = branchRefs
                    .filter { it.type == REMOTE_BOOKMARK_REF_TYPE }
                    .groupBy { it.name.substringBefore('/', missingDelimiterValue = it.name) }

                return buildList {
                    if (localRefs.isNotEmpty()) {
                        add(SimpleRefGroupFactory.create("Local bookmarks", localRefs.toMutableList()))
                    }
                    remoteGroups.toSortedMap().forEach { (remote, refsForRemote) ->
                        add(SimpleRefGroupFactory.create(remote, refsForRemote.toMutableList()))
                    }
                }
            }

            override fun groupForTable(refs: Collection<VcsRef>, compact: Boolean, expanded: Boolean): List<RefGroup> {
                val refsByType = MultiMap.create<VcsRefType, VcsRef>()
                refs.forEach { refsByType.putValue(it.type, it) }
                return SimpleRefGroup.buildGroups(emptyList(), refsByType, compact, expanded)
            }

            override fun serialize(output: DataOutput, type: VcsRefType) {
                val index = REF_TYPES.indexOf(type)
                if (index < 0) {
                    throw IOException("Unknown Selvejj ref type: $type")
                }
                output.writeInt(index)
            }

            override fun deserialize(input: DataInput): VcsRefType {
                val index = input.readInt()
                return REF_TYPES.getOrNull(index)
                    ?: throw IOException("Unknown Selvejj ref type index: $index")
            }

            override fun isFavorite(ref: VcsRef): Boolean = false
            override fun setFavorite(ref: VcsRef, favorite: Boolean) {}
        }
    }

    override fun getSupportedVcs(): VcsKey = SelvejjVcs.getKey()
}

class SelvejjChangesParser : VcsChangesLazilyParsedDetails.ChangesParser {
    override fun parseStatusInfo(
        project: Project,
        commit: VcsShortCommitDetails,
        changes: List<VcsFileStatusInfo?>,
        parentIndex: Int
    ): List<Change?>? {
        val repositoryRoot = commit.root.path
        val parentCommit = if (commit.parents.isNotEmpty()) commit.parents[parentIndex] else null

        return changes.map { info ->
            info?.let {
                when (it.type) {
                    Change.Type.MODIFICATION -> {
                        val beforePath = VcsUtil.getFilePath("$repositoryRoot/${it.firstPath}", false)
                        val afterPath = VcsUtil.getFilePath("$repositoryRoot/${it.secondPath!!}", false)
                        Change(
                            createHistoricalContentRevision(beforePath, parentCommit, repositoryRoot),
                            createHistoricalContentRevision(afterPath, commit.id, repositoryRoot),
                            FileStatus.MODIFIED
                        )
                    }

                    Change.Type.NEW -> {
                        val afterPath = VcsUtil.getFilePath("$repositoryRoot/${it.secondPath!!}", false)
                        Change(
                            null,
                            createHistoricalContentRevision(afterPath, commit.id, repositoryRoot),
                            FileStatus.ADDED
                        )
                    }

                    Change.Type.DELETED -> {
                        val beforePath = VcsUtil.getFilePath("$repositoryRoot/${it.firstPath}", false)
                        Change(
                            createHistoricalContentRevision(beforePath, parentCommit, repositoryRoot),
                            null,
                            FileStatus.DELETED
                        )
                    }

                    Change.Type.MOVED -> {
                        val beforePath = VcsUtil.getFilePath("$repositoryRoot/${it.firstPath}", false)
                        val afterPath = VcsUtil.getFilePath("$repositoryRoot/${it.secondPath!!}", false)
                        Change(
                            createHistoricalContentRevision(beforePath, parentCommit, repositoryRoot),
                            createHistoricalContentRevision(afterPath, commit.id, repositoryRoot),
                            FileStatus.MODIFIED
                        )
                    }
                }
            }
        }
    }

    private fun createHistoricalContentRevision(
        filePath: FilePath,
        revisionHash: Hash?,
        repositoryRoot: String
    ): SelvejjHistoricalContentRevision? {
        if (revisionHash == null) return null

        val relativePath = filePath.path.removePrefix("$repositoryRoot/")
        return SelvejjHistoricalContentRevision(
            filePath = filePath,
            revisionNumber = SelvejjRevisionNumber(revisionHash.asString()),
            repositoryRoot = repositoryRoot,
            relativePath = relativePath
        )
    }
}
