package com.selvejj

import com.intellij.vcs.log.VcsRef
import com.intellij.vcs.log.impl.SimpleRefGroup

internal object SimpleRefGroupFactory {
    fun create(name: String, refs: MutableList<VcsRef>): SimpleRefGroup {
        val constructor = SimpleRefGroup::class.java.getConstructor(
            String::class.java,
            List::class.java
        )
        return constructor.newInstance(name, refs)
    }
}
