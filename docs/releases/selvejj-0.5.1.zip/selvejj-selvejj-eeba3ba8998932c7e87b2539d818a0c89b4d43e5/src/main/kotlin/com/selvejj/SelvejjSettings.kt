/*
 * Copyright (c) 2025 Nikhil Marathe <nikhil@selvejj.com>
 */

package com.selvejj

import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.components.PersistentStateComponent
import com.intellij.openapi.components.Service
import com.intellij.openapi.components.State
import com.intellij.openapi.components.Storage
import com.intellij.util.xmlb.XmlSerializerUtil

@Service(Service.Level.APP)
@State(name = "SelvejjSettings", storages = [Storage("selvejj.xml")])
class SelvejjSettings : PersistentStateComponent<SelvejjSettings.State> {
    data class State(var jjPath: String = "jj")

    private var state = State()

    var jjPath: String
        get() = state.jjPath
        set(value) {
            state.jjPath = value
        }

    override fun getState(): State = state

    override fun loadState(state: State) {
        XmlSerializerUtil.copyBean(state, this.state)
    }

    companion object {
        fun getInstance(): SelvejjSettings =
            ApplicationManager.getApplication().getService(SelvejjSettings::class.java)
    }
}
