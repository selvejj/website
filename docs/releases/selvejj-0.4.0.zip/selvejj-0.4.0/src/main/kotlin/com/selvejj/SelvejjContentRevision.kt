/*
 * Copyright (c) 2025 Nikhil Marathe <nikhil@selvejj.com>
 */

package com.selvejj

import com.intellij.openapi.vcs.FilePath
import com.intellij.openapi.vcs.changes.CurrentContentRevision

class SelvejjContentRevision(
    filePath: FilePath
) : CurrentContentRevision(filePath)